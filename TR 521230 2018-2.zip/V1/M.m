function r=M(n)
r=[2/n,0,cos(pi*n)/n;1,1,1/n;1+1/n,0,1];