clear all; close all; clc;
load salmones.mat
subplot(1,3,1);plot(K,'LineWidth',2);
subplot(1,3,2);plot(T,'LineWidth',2);
subplot(1,3,3);plot(P,'LineWidth',2);